# Dinosaur Game Chrome

A Pen created on CodePen.io. Original URL: [https://codepen.io/MysticReborn/pen/rygqao](https://codepen.io/MysticReborn/pen/rygqao).

